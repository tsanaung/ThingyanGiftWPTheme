<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package MyanmarIA_Publisher
 */

get_header();
?>


<?php $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'large' ); ?>


<div class="w3-row" style="margin-top:33px;"><!-- Main Layout Starts-->
	
	
	<div class="w3-quarter w3-padding w3-hide-small"> <!-- Left Sidebar-->
		<div class="tsan-sidebar">
			<?php if ( is_active_sidebar( 'tlwget' ) ) : ?>
			<?php dynamic_sidebar( 'tlwget' ); ?>
			<?php endif; ?>
		</div>
	</div>
	
	<div class="w3-half"> <!-- Main Centent -->
		
		<a href="<?php the_permalink(); ?>"> </a>
		<img src="<?php echo $large_image_url[0]; ?>">
		<p class="w3-large w3-padding w3-panel w3-blue w3-text-white w3-border-bottom">
			<?php the_title(); ?>
		</p>
		<div class="w3-container">
			<span class="w3-small t-on-fimg"><?php myanmaria_tsan_cat(); ?> | <?php myanmaria_tsan_date(); ?></span><hr/>
			<?php the_content(); ?>
		</div>
		
	</div>
	
	<div class="w3-quarter"> <!-- Right Sidebar-->
		<div class="tsan-sidebar">
			<?php get_sidebar(); ?>
		</div>
	</div>
	
	
	
</div> <!--Main Layout Ends-->

		<div class="tsan-footer-widget">
			<?php if ( is_active_sidebar( 'tfwget' ) ) : ?>
			<?php dynamic_sidebar( 'tfwget' ); ?>
			<?php endif; ?>
		</div>


<?php
//get_sidebar();
get_footer();
?>













	


	

	

	
