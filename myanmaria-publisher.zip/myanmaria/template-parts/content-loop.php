	<?php $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'large' ); ?>

<div class="taipl w3-border-bottom">
<div class="w3-row w3-border-bottom w3-border-bar w3-round">
	<a href="<?php the_permalink(); ?>">
	<div class="w3-third">
		<div class="aspect-ratio-box">
			<img src="<?php echo $large_image_url[0]; ?>" style="width:100%">
		</div>
	</div>
	</a>
	<div class="w3-twothird">
		
		<span class="w3-small t-on-fimg"><?php myanmaria_tsan_cat(); ?> | <?php myanmaria_tsan_date(); ?></span>
		<a href="<?php the_permalink(); ?>">
		<div>
		<span class="tin-poloop"><?php the_title(); ?></span>
		<div class="ein-poloop w3-small w3-hide-small"><?php the_excerpt(); ?></div>
	    </div>
		</a>
	</div>
</div>
</div>



	


