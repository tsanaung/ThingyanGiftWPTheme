<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package MyanmarIA_Publisher
 */

?>



<?php wp_footer(); ?>

<div class="w3-center w3-white w3-large">
	<footer>
		&copy;2020 <?php bloginfo('name'); ?> | All Rights Reserved <br/>
		<a href="https://myanmaria.com">MyanmarIA Publisher Theme</a> by <a href="https://facebook.com/tsanaung">Tsan Aung</a>
	</footer>
</div>

</body>
</html>
