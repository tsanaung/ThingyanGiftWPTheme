<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package MyanmarIA_Publisher
 */
show_admin_bar(false);
?>

<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
	
	<link rel="stylesheet" href="https://myanmaria.com/cdn/fonts/MyanmarSagar(Unicode)/style.css">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

	<script src="<?php echo get_template_directory_uri();?>/ui/js/nav.js?v=1"></script>
	

</head>

<body class="t-body">
	
	<nav class="w3-sidebar w3-bar-block w3-animate-right w3-top" style="z-index:3;width:250px;font-weight:bold;display:none;right:0;" id="mySidebar">
		
		<a href="<?php bloginfo('wpurl'); ?>" onclick="w3_close()" class="w3-bar-item w3-button">Home</a>
		
<?php

                $menuParameters = array(
                    'menu' => 'primary_menu',
                    'link_before'     => '<span onclick="w3_close()" class="w3-bar-item w3-button">',
                    'link_after'      => '</span>',
                    'before'        => '<div class="tsan-menu-item">',
                    'after'     => '</div>',
                    'container'       => false,
                    'echo'            => false,
                    'depth'           => 0,
                );

                echo strip_tags(wp_nav_menu( $menuParameters ), '<a><span><div>' );
?>
		<a href="javascript:void()" onclick="w3_close()" class="w3-bar-item w3-button">Close</a>

	</nav>
	
	<header class="w3-top w3-white w3-xlarge">
		<a href="<?php bloginfo('wpurl'); ?>" class="w3-left w3-padding no-atext-decor w3-text-blue">
			<?php bloginfo('name'); ?>
		</a>
		<a href="javascript:void(0)" class="w3-right w3-button w3-white w3-padding w3-text-blue" onclick="w3_open()">☰</a>
	</header>
	
	<!--Overlay efffect Important-->
	<div class="w3-overlay w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>
	
	
