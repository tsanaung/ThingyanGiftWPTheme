<?php
/**
 * The main template file
 */

get_header(); //calling header.php
?>

<!--Main index root-->
<div id="tsan-main-root" class="tsanc-light-grey">
	

<div class="tsan-row">

<div id="tsan-desktop-sidemenu" class="tsan-quarter tsan-container sidenavpanel">
	
<div class="tsan-sidebar tsan-bar-block">
<!--Sidebar Menu Starts-->
<?php
wp_nav_menu( array( 
    'theme_location' => 'tsan-custom-menu', 
    'container_class' => 'custom-menu-class' ) ); 
?><!--Sidebar Menu Ends-->

<!--Left sidebar widget starts-->
<?php dynamic_sidebar( 'tsan_left_sw' ); ?> <!--left sidebar ends-->
</div>

</div>
	
	
<div id="tsan-thumbinposts-loop" class="tsan-half tsan-row tsan-border-bottom">
	

<?php
if ( have_posts() ) : while ( have_posts() ) : the_post();

		get_template_part( 'template-parts/posts_loop', get_post_type() );

	endwhile;

	the_posts_pagination( array(
		'prev_text' => __( 'Previous page' ),
		'next_text' => __( 'Next page' ),
	) );

endif;
?>
	
	
</div>
<!-- EndsTsanLoop-->

<div class="tsan-quarter tsan-container">
<!--Right sidebar widget starts-->
<?php dynamic_sidebar( 'tsan_right_sw' ); ?> <!--Right sidebar ends-->
</div>

</div>
	
</div><!--Main Index root-->
<?php get_footer(); ?>