// Script to open and close sidebar
function tsan_open() {
  document.getElementById("mySidebar").style.display = "block";
};
 
function tsan_close() {
  document.getElementById("mySidebar").style.display = "none";
};