<div class="tsan-center">
<?php wp_footer(); ?>
<p class="tsan-padding-top tsan-small">
	Copyright&copy; 2020 <?php bloginfo( 'name' ); ?> | All Rights Reserved<br/>Thingyan Gift Theme by Tsan Aung
</p>
</div>