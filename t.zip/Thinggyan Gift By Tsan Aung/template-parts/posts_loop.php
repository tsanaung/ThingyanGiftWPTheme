<?php $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'large' ); ?>

<div class" tsan-margin-6px">
	

<a href="<?php the_permalink(); ?>" id="tsan-linkinpostloop" class="tsan-border tsan-round tsan-half">


	
  <img src="<?php echo $large_image_url[0]; ?>" style="width:100%">
	

	
	
	<span class="tsan-titleipl"> <?php the_title(); ?></span>
	<span class="tsan-wbe"> <?php the_excerpt(); ?></span><br/>
	
	

	
</a>
</div>