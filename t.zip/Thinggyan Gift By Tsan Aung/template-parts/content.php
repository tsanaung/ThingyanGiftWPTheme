<?php $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'large' ); ?>
<div id="tsan-single">
<img src="<?php echo $large_image_url[0]; ?>" /> <h3 class="tsan-border-bottom" style="border-width:6px;"><?php the_title(); ?></h3><?php the_content(); ?> 
</div>
