<?php
/**
 * Functions and definitions
 *
 */

/*
 * Let WordPress manage the document title.
 */
add_theme_support( 'title-tag' );

/*
 * Enable support for Post Thumbnails on posts and pages.
 */
add_theme_support( 'post-thumbnails' );

/*
 * Switch default core markup for search form, comment form, and comments
 * to output valid HTML5.
 */
add_theme_support( 'html5', array(
	'search-form',
	'comment-form',
	'comment-list',
	'gallery',
	'caption',
) );

/**
 * Include primary navigation menu
 */
function tsan_nav_init() {
	register_nav_menus( array(
		'menu-1' => 'Primary Menu',
	) );
}
add_action( 'init', 'untheme_nav_init' );

/**
 * Register widget area.
 *
 */
function tsan_widgets_init() {
	register_sidebar( array(
		'name'          => 'Sidebar',
		'id'            => 'sidebar-1',
		'description'   => 'Add widgets',
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'tsan_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function tsan_scripts() {
	wp_enqueue_style( 'tsan-style', get_stylesheet_uri() );
	wp_enqueue_style( 'tsan-custom-style', get_template_directory_uri() . '/assets/css/style.css' );
	wp_enqueue_style( 'tsan-custom-style', get_template_directory_uri() . '/assets/css/style.scss' );
	wp_enqueue_script( 'tsan-scripts', get_template_directory_uri() . '/assets/js/scripts.js' );
}
add_action( 'wp_enqueue_scripts', 'tsan_scripts' );



function wp_nav_menu_no_ul()
{
$options = array(
'echo' => false,
'container' => false,
'theme_location' => 'primary',
'fallback_cb'=> 'default_page_menu'
);

$menu = wp_nav_menu($options);
echo preg_replace(array(
'#^<ul[^>]*>#',
'#</ul>$#'
), '', $menu);

}

function default_page_menu() {
wp_list_pages('title_li=');
}

//set thumbnail size
//

//set_post_thumbnail_size( 320, 180 );
add_filter( 'post_thumbnail_html', 'my_post_image_html', 10, 3 );

function my_post_image_html( $html, $post_id, $post_image_id ) {

  $html = '<a href="' . get_permalink( $post_id ) . '" title="' . esc_attr( get_post_field( 'post_title', $post_id ) ) . '">' . $html . '</a><br/>';
  return $html;

}

/*limiting excerpt length by character count*/
function get_excerpt(){
$excerpt = get_the_content();
$excerpt = preg_replace(" ([.*?])",'',$excerpt);
$excerpt = strip_shortcodes($excerpt);
$excerpt = strip_tags($excerpt);
$excerpt = substr($excerpt, 0, 15);
$excerpt = substr($excerpt, 0, strripos($excerpt, " "));
$excerpt = trim(preg_replace( '/\s+/', ' ', $excerpt));
$excerpt = $excerpt.'... <a href="'.get_the_permalink().'">more</a>';
return $excerpt;
}

/* Addin custom nav menu by TsanAung-->
 *
 */
function tsan_custom_new_menu() {
  register_nav_menu('tsan-custom-menu',__( 'Sidebar Navigation Menu By Tsan Aung' ));
}
add_action( 'init', 'tsan_custom_new_menu' );


/*Registering Tsan's custom widget
 */

function register_widget_areas() {

  register_sidebar( array(
    'name'          => 'Left sidebar widget by Tsan Aung',
    'id'            => 'tsan_left_sw',
    'description'   => 'This widget area discription',
    'before_widget' => '<section id="tsan-left-sw">',
    'after_widget'  => '</section>',
    'before_title'  => '<div style="display:none;">',
    'after_title'   => '</div>',
  ));

  register_sidebar( array(
    'name'          => 'Right sidebar widget by Tsan Aung',
    'id'            => 'tsan_right_sw',
    'description'   => 'This widget area discription',
    'before_widget' => '<section id="tsan-left-sw">',
    'after_widget'  => '</section>',
    'before_title'  => '<div style="display:none;">',
    'after_title'   => '</div>',
  ));

  register_sidebar( array(
    'name'          => 'Footer widget by Tsan Aung',
    'id'            => 'tsan_footer_sw',
    'description'   => 'This widget area discription',
    'before_widget' => '<section id="tsan-left-sw">',
    'after_widget'  => '</section>',
    'before_title'  => '<div style="display:none;">',
    'after_title'   => '</div>',
  ));

}

add_action( 'widgets_init', 'register_widget_areas' );
