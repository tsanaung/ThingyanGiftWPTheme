<?php
/**
 * The header for the theme
 * you can customise navbar. menu, logo
 */
?>

<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php bloginfo( 'name' ); ?></title>
	<script src="https://kit.fontawesome.com/651166a3c3.js" crossorigin="anonymous"></script>
	<?php wp_head(); ?>
</head>

<body>
	
<!-- Navbar (Responsive) -->

<!-- Sidebar (hidden by default) -->
<nav class="tsan-sidebar tsan-bar-block tsan-card tsan-top tsan-large tsan-animate-left" style="display:none;z-index:2;width:40%;min-width:300px" id="mySidebar">
  <a href="javascript:void(0)" onclick="tsan_close()"
  class="tsan-bar-item tsan-button">Close Menu</a>
<div id="tsan-desktop-sidemenu" class="tsan-bar-item">
<?php
	
$menuParameters = array(
  'container'       => false,
  'echo'            => false,
  'items_wrap'      => '%3$s',
  'depth'           => 0,
);

echo strip_tags(wp_nav_menu( $menuParameters ), '<a>' );

?>
	 </div>
</nav>

<!-- Top menu -->
<div class="tsan-top tsan-card">
  <div class="tsan-white tsan-large" style="max-width:1200px;margin:auto">
    <div class="tsan-button tsan-padding-16 tsan-left" onclick="tsan_open()">☰</div>
    <div class="tsan-right tsan-padding-16 tsan-margin-right"><i class="fas fa-info-circle"></i></div>
    <div class="tsan-center tsan-padding-16"><?php bloginfo( 'name' ); ?></div>
  </div>
</div>
	
	
<?php
	/*
$menuParameters = array(
  'container'       => false,
  'echo'            => false,
  'items_wrap'      => '%3$s',
  'depth'           => 0,
);

echo strip_tags(wp_nav_menu( $menuParameters ), '<a>' );
*/
?>
